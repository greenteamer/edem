<?php

/**
 * @file
 * Test PHP file for Libraries loading.
 */

/**
 * Dummy function to see if this file was loaded.
 */
function _libraries_test_module_example_4() {
}
